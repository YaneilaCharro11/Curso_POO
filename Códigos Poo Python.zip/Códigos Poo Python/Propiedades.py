class Persona:
    def __init__(self,nombre,edad):
        self.__nombre=nombre
        self.__edad=edad

    @property
    def nombre(seft):
        return seft.__nombre
    
   

dalton=Persona("Lucas",21)

nombre= dalton.nombre
print(nombre)

