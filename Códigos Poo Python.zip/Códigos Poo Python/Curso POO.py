class Celular():
    marca = "iphone"
    modelo = "X"
    camara = "58MP"

celular1= Celular()
celular2= Celular()
celular3= Celular()
celular4= Celular()

print(celular4.marca)
