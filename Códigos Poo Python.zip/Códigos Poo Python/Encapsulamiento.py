class Miclase:
    def __init__(self):
        self._atributo__privado = "Valor"

objeto=Miclase()
print(objeto._atributo__privado)